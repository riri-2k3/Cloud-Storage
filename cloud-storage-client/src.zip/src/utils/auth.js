import { toast } from 'react-toastify';

export const handleAuthError = (error) => {
    const errorMsg = error.response?.data?.error || 'An error occurred. Please try again.';
    toast.error(errorMsg);
    return errorMsg;
};

export const setAuthToken = (token) => {
    if (token) {
        localStorage.setItem('token', token);
        return true;
    }
    return false;
};

export const getAuthToken = () => {
    return localStorage.getItem('token');
};

export const removeAuthToken = () => {
    localStorage.removeItem('token');
};

export const getDecodedToken = () => {
    const token = getAuthToken();
    if (!token) return null;
    try {
        return JSON.parse(atob(token.split('.')[1]));
    } catch (error) {
        console.error('Error decoding token:', error);
        return null;
    }
};

export const isAuthenticated = () => {
    return !!getAuthToken();
};
