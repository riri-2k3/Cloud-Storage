import axios from 'axios';
import { getAuthToken } from './auth';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';

// Create axios instance with default config
const axiosInstance = axios.create({
    baseURL: API_BASE_URL,
    headers: {
        'Content-Type': 'application/json'
    }
});

// Add auth token to requests
axiosInstance.interceptors.request.use(
    (config) => {
        const token = getAuthToken();
        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

// Handle response errors globally
axiosInstance.interceptors.response.use(
    (response) => response,
    (error) => {
        if (error.response?.status === 401) {
            // Handle unauthorized access
            window.location.href = '/login';
        }
        return Promise.reject(error);
    }
);

export const api = {
    // Auth endpoints
    login: async (email, password) => {
        const response = await axiosInstance.post('/api/users/login', { email, password });
        return response.data;
    },
    
    signup: async (email, password) => {
        const response = await axiosInstance.post('/api/users/register', { email, password });
        return response.data;
    },

    // User endpoints
    getUserProfile: async () => {
        const response = await axiosInstance.get('/api/users/profile');
        return response.data;
    },

    updateProfile: async (userData) => {
        const response = await axiosInstance.put('/api/users/profile', userData);
        return response.data;
    },

    // File endpoints
    uploadFile: async (formData) => {
        const response = await axiosInstance.post('/api/files/upload', formData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        });
        return response.data;
    },

    listFiles: async () => {
        const response = await axiosInstance.get('/api/files');
        return response.data;
    },

    deleteFile: async (fileId) => {
        const response = await axiosInstance.delete(`/api/files/${fileId}`);
        return response.data;
    },

    downloadFile: async (fileId) => {
        const response = await axiosInstance.get(`/api/files/${fileId}/download`, {
            responseType: 'blob'
        });
        return response.data;
    }
};

export default api;
